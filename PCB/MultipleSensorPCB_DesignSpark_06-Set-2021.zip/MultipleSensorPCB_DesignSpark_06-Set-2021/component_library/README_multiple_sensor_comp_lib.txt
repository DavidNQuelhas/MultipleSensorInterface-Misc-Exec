
Multiple-Sensor Interface components library for PCB on DesignSpark 9.

- Place the component library files of 'multiple_sensor_component_lib' on the folder:  
C:\Users\Public\Documents\DesignSpark PCB 9.0\Library\User


#   Multiple Sensor Interface PCB - PCB design/layout of a versatile RTU device.
#   Copyright (C) 2021 by David Nuno Quelhas; Lisboa, Portugal;
#   david.quelhas@yahoo.com ,  https://multiple-sensor-interface.blogspot.com 
#   LICENSE: CERN Open Hardware Licence Version 2 - Weakly Reciprocal (CERN-OHL-W)
