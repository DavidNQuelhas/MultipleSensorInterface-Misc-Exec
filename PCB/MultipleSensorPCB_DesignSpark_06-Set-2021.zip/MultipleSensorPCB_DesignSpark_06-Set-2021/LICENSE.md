

#   Multiple Sensor Interface PCB

####   Multiple Sensor Interface PCB - PCB design/layout of a versatile RTU device.
###   Copyright (C) 2021 by David Nuno Quelhas; Lisboa, Portugal;
###   david.quelhas@yahoo.com ,  https://multiple-sensor-interface.blogspot.com 

### LICENSE: CERN Open Hardware Licence Version 2 - Weakly Reciprocal (CERN-OHL-W)                                                                           
> Preamble:
> CERN has developed this licence to promote collaboration among hardware designers and to provide a legal tool which supports
> the freedom to use, study, modify, share and distribute hardware designs and products based on those designs.
> The CERN-OHL-W is copyright CERN 2020. Anyone is welcome to use it, in unmodified form only.
> Use of this Licence does not imply any endorsement by CERN of any Licensor or their designs nor does it imply any involvement by CERN in their development.

 